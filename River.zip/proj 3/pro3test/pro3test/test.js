var body = d3.select("body");


var margin = {top: 20, right: 20, bottom: 30, left: 20},
    width = 1100 - margin.left - margin.right,
    height = 500 - margin.top - margin.bottom;

var svg = d3.select("body").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform",
          "translate(" + margin.left + "," + margin.top + ")");

//best fit line = y = -0.0005x + 82.445 for R0

var bestFit = function(x){
				return -0.0005*x + 82.445;
}

var scale = d3.scaleLinear()
				.domain([1,1602])
				.range([0,1000]);				
				
d3.csv("R0.csv", function(data){
	svg.selectAll("circle")
	  .data(data)
	  .enter()
	  .append("circle")
	  .attr("cx", function(d){return scale(d["x_interp"]);})
	  .attr("cy", function(d){return 3000-d["z_interp"]*35;})
	  .attr("r", .5)
	  .attr("stroke", "black")
	  .attr("stroke-width", .5)
	  .style("fill","black");
	  
	data.forEach(function(e){ 
		svg.append("circle")
		  .attr("cx", function(d){return scale(e["x_interp"]);})
		  .attr("cy", function(d){return 3000-e["wse_interp"]*35;})
		  .attr("r", .5)
		  .attr("stroke", "red")
		  .attr("stroke-width", .5)
		  .style("fill","red");
	});
	
	svg.append("path")
		.attr("d", function(d){return "M 0 114.425 L " + scale(1602) + " 142.46";})
		.attr("stroke-width", 1)
		.attr("stroke", "black");
	var rotation = 0;	
	var flag = 0;
	var peaks =[];
    
	if (data[0]["z_interp"] > bestFit(0))
	{
		flag = 0;
	}
	else
	{
		flag = 1;
	}
	
	for(var i = 0; i < data.length; i++)
	{
		if (flag == 0)
		{
			var peak = 0;
			var index = 0;
			var x = i;
			while(x < data.length && data[x]["z_interp"] > bestFit(x+1))
			{
				if (data[x]["z_interp"] > peak)
				{
					peak = data[x]["z_interp"];
					index = x;
				}
				x++;
			}
			peaks.push([index,peak]);
			i = x;
			flag = 1;

		}
		if (flag == 1)
		{
			var peak = 1000;
			var index = x;
			var x = i;
			while(x < data.length && data[x]["z_interp"] < bestFit(x+1))
			{
				if (data[x]["z_interp"] < peak)
				{
					peak = data[x]["z_interp"];
					index = x;
				}
				x++;
			}
			peaks.push([index,peak]);
			i = x;
			flag = 0;
		}
	}
	
	/*console.log(peaks);
	console.log(peaks[0]);
	console.log(peaks[1]);
	console.log(peaks[2]);
	console.log(peaks[3]);
	console.log(peaks[4]);*/
	
	peaks.forEach(function(e){ 
		svg.append("circle")
		  .attr("cx", function(d){return scale(e[0]);})
		  .attr("cy", function(d){return 3000-e[1]*35;})
		  .attr("r", 3)
		  .attr("stroke", "black")
		  .attr("stroke-width", 1)
		  .style("fill","red");
	});
});
			   
  